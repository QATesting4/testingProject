

class xss_blank3 {
    public static void main(String[] args) {
        System.out.println("Hello, World!"); 
    }
}
