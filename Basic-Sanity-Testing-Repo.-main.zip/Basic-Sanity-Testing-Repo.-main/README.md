# consul-template
Minimal docker container containing the latest consul-template and docker release.

For instructions how to use consul-template, see the consule-template documentation: 
https://github.com/hashicorp/consul-template

You can also have a look at the examples: https://github.com/avthart/docker-consul-template/blob/master/examples/examples.md


Sanity Testing

This reposetory can be used for Testing.
